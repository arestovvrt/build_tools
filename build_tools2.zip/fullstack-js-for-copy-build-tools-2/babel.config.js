const plugins = [];

module.exports = {
  presets: ["@babel/preset-env"],
  plugins,
};
